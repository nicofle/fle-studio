export default class Engine {
  async init() {
    this.data = {
      nouns: [
        { lemma: 'chat', article: 'Le' },
        { lemma: 'chien', article: 'Le' }
      ],
      verbs: [
        { present: { thirdPersonSingular: 'mange' } },
        { present: { thirdPersonSingular: 'court' } }
      ]
    };
  }

  generate() {
    const noun = this.data.nouns[Math.floor(Math.random() * this.data.nouns.length)];
    const verb = this.data.verbs[Math.floor(Math.random() * this.data.verbs.length)];

    return `${noun.article} ${noun.lemma} ${verb.present.thirdPersonSingular}.`;
  }
}
